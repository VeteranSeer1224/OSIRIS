"""
OSIRIS Mind Module
"""
