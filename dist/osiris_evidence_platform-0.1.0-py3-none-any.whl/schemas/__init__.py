"""
OSIRIS Pipeline Schemas Package
"""
